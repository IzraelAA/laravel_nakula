@extends('superadmin.dashboardadmin')

@section('content')
    
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active">Data Quiz</li>
            </ol>
        </div>
        {{-- <div class="col-md-6 col-4 align-self-center">
            <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a>
        </div> --}}
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-8">
          <div class="card">
            <div class="card-body">
              <div class="row justify-content-center">
                <div class="col-md-8">
                <form action="{{route('raportinsert')}}" method="POST">
                     @csrf
                     
                      <div class="form-group">
                          <label for="formGroupExampleInput">Mata Pelajaran</label>
                          <select name="id_dataquiz" id="id_dataquiz" class="form-control" readonly>
                          @foreach ($kelas ?? '' as $data)
                          <option value="{{$data->id_mapel}}">{{$data->nama_pelajaran}}</option>
                          @endforeach
                          </select>
                      </div>
                      <div class="row">
                        <div class="col">
                            <label for="nama">Nilaai</label>   
                           <input type="text" class="form-control" name="nilai" id="nilai"  placeholder="Nilai....">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="formGroupExampleInput2">tipe</label>
                        <input type="text" class="form-control" name="tipe" id="tipe"  placeholder="Tipe....">
                      </div>                
                      
                      <div class="form-group">
                     <button type="submit" class="btn btn-primary">Simpan</button>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div> 
    <!-- Row -->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>


  
 

@endsection